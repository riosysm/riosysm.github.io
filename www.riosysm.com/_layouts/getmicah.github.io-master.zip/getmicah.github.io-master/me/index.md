---
layout: about
---

Hello, my name is Micah Cowell. I'm 17 years old living in Washington state. I like the internet, hip hop, and over-priced yo-yos. I make websites in the way I see most appealing and write code to put on Github.

[//]: # # What is with the website url?
[//]: # The url hac.im is just my name backwards.

# What do you do?
I write code

# Who are your favorite artists?
I currently like Oshi, Anderson Paak, and Common.

# What programming languages do you use?
I like using Javascript and Sass when making websites but I also like Python and Haskell.

# Which sports teams do you follow?
I like following the Mariners but hate watching baseball. University of Washington football and basketball. Waiting for the Supersonics.
