# getmicah.github.io
My blog made with [jekyll](http://jekyllrb.com) and hosted with Github Pages.

### License
All this stuff is under the [MIT License](https://raw.githubusercontent.com/getmicah/getmicah.github.io/master/LICENSE)
